import socket
import webbrowser
import os

SERVER_HOST = '10.53.126.132'  # Server IP address
SERVER_PORT = 8080

def fetch_html_page():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((SERVER_HOST, SERVER_PORT))

    # Construct the GET request for the HTML page
    request_data = "GET /index.html HTTP/1.1\r\nHost: localhost:8080\r\n\r\n"

    # Send the GET request to the server
    client_socket.sendall(request_data.encode())

    # Receive the server's response
    response_data = client_socket.recv(4096).decode()

    # Close the socket
    client_socket.close()

    # Extract HTML content from the response
    html_content = response_data.split('\r\n\r\n', 1)[-1]

    # Determine the full path to the output directory
    output_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'output'))

    # Ensure that the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Construct the full path to the HTML file
    html_file_path = os.path.join(output_dir, 'index.html')

    # Save HTML content to a local file
    with open(html_file_path, 'w') as html_file:
        html_file.write(html_content)

    # Open the saved HTML file in a web browser
    webbrowser.open(html_file_path)

if __name__ == "__main__":
    fetch_html_page()