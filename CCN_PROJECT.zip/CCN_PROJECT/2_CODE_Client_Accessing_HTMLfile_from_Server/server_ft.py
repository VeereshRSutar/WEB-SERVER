import socket
import os

HOST = '0.0.0.0'  # Listen on all available interfaces
PORT = 8080

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen()

    print(f"Server listening on {HOST}:{PORT}...")

    while True:
        client_socket, _ = server_socket.accept()
        handle_client_request(client_socket)

def handle_client_request(client_socket):
    request_data = client_socket.recv(4096).decode()
    request_lines = request_data.split("\r\n")

    if request_lines:
        # Extract the requested filename from the HTTP request
        filename = request_lines[0].split(" ")[1]

        # Serve the requested file
        serve_file(client_socket, filename)

    client_socket.close()

def serve_file(client_socket, filename):
    # Construct the path to the requested file
    file_path = os.path.join(os.path.dirname(__file__), filename.strip('/'))

    # Check if the requested file exists
    if filename == '/index.html' and os.path.exists(file_path) and os.path.isfile(file_path):
        # Read the contents of the file
        with open(file_path, 'r') as file:
            file_data = file.read()

        # Send the HTTP response with the file content
        response_data = f"HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n{file_data}"
    else:
        # If the requested file doesn't exist, send a 404 Not Found response
        response_data = "HTTP/1.1 404 Not Found\r\nContent-Type: text/plain\r\n\r\n404 Not Found"

    client_socket.sendall(response_data.encode())

if __name__ == "__main__":
    start_server()
