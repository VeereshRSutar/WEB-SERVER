import socket

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 8080

def send_request():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((SERVER_HOST, SERVER_PORT))

    request_data = "GET / HTTP/1.1\r\nHost: localhost:8080\r\n\r\n"
    client_socket.sendall(request_data.encode())

    response_data = client_socket.recv(4096).decode()
    print("Server Response:")
    print(response_data)

    client_socket.close()

if __name__ == "__main__":
    send_request()
