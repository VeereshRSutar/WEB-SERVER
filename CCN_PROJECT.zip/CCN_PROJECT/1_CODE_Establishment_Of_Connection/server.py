import socket

HOST = '127.0.0.1'  # localhost
PORT = 8080

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen()

    print(f"Server listening on {HOST}:{PORT}...")

    while True:
        client_socket, _ = server_socket.accept()
        handle_client_request(client_socket)

def handle_client_request(client_socket):
    request_data = client_socket.recv(1024).decode()
    if request_data:
        print("Received request:")
        print(request_data)

        response_data = "Hey bois,connection between server and client established successfully"
        client_socket.sendall(response_data.encode())

    client_socket.close()

if __name__ == "__main__":
    start_server()
