import webbrowser

def main():
    SERVER_IP = '10.53.126.132'  # Replace with the server's IP address
    SERVER_PORT = 8080  # Replace with the server's port number

    # Construct the server URL
    SERVER_URL = f'http://{SERVER_IP}:{SERVER_PORT}'

    # Open login page in web browser
    webbrowser.open(SERVER_URL)

if __name__ == '__main__':
    main()