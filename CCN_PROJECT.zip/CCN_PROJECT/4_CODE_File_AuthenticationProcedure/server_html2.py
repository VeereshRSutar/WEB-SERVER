from http.server import BaseHTTPRequestHandler, HTTPServer
import webbrowser

# Define valid username-password pairs
valid_credentials = {
    'Veeresh': '123',
    'Tejas': '456'
}

class MyHTTPHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        form_fields = post_data.split('&')
        form_data = {}
        for field in form_fields:
            key, value = field.split('=')
            form_data[key] = value

        if 'username' in form_data and 'password' in form_data:
            username = form_data['username']
            password = form_data['password']
            if username in valid_credentials and valid_credentials[username] == password:
                self.send_response(303)
                self.send_header('Location', '/index.html')
                self.end_headers()
            else:
                self.send_response(401)
                self.end_headers()
                self.wfile.write(b"Login failed. Please try again.")
        else:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"Bad request. Please provide username and password.")

    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            with open('login.html', 'rb') as file:
                self.wfile.write(file.read())
        elif self.path == '/index.html':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            with open('index.html', 'rb') as file:
                self.wfile.write(file.read())
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not found.")

def main():
    try:
        server_address = ('', 8080)
        httpd = HTTPServer(server_address, MyHTTPHandler)
        print('Server running on port 8080...')
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('^C received, shutting down the server')
        httpd.socket.close()

if __name__ == '__main__':
    main()
