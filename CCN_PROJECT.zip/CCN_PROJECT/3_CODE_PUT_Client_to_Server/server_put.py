import socket
import os

HOST = '0.0.0.0'  # Listen on all available interfaces
PORT = 8080

UPLOAD_DIR = "C:\\Users\\Tejas\\Desktop\\CCN2"  # Directory to store uploaded files

def start_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((HOST, PORT))
    server_socket.listen()

    print(f"Server listening on {HOST}:{PORT}...")

    while True:
        client_socket, _ = server_socket.accept()
        handle_client_request(client_socket)

def handle_client_request(client_socket):
    request_data = client_socket.recv(4096).decode()

    if request_data.startswith("PUT"):
        handle_put_request(request_data, client_socket)
    else:
        # Handle other types of requests (e.g., GET, POST) here
        pass

    client_socket.close()

def handle_put_request(request_data, client_socket):
    # Extract the filename from the request URI
    uri_parts = request_data.split(" ")
    filename = uri_parts[1].split("/")[-1]

    # Extract the file data from the request body
    request_body_parts = request_data.split("\r\n\r\n")
    file_data = request_body_parts[-1]

    # Save the file data to the uploads directory
    file_path = os.path.join(UPLOAD_DIR, filename)
    with open(file_path, 'wb') as file:
        file.write(file_data.encode())

    # Send a response indicating successful file upload
    response_data = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\nFile uploaded successfully!"
    client_socket.sendall(response_data.encode())

if __name__ == "__main__":
    if not os.path.exists(UPLOAD_DIR):
        os.makedirs(UPLOAD_DIR)

    start_server()
