import socket

SERVER_HOST = '127.0.0.1'  # Replace with the IP address of the server machine
SERVER_PORT = 8080

def send_file(filename):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((SERVER_HOST, SERVER_PORT))

    with open(filename, 'rb') as file:
        file_data = file.read()

    # Construct the PUT request with the file data
    request_data = f"PUT /upload/{filename} HTTP/1.1\r\nHost: {SERVER_HOST}:{SERVER_PORT}\r\nContent-Length: {len(file_data)}\r\n\r\n{file_data}"

    # Send the PUT request with the file data
    client_socket.sendall(request_data.encode())

    # Receive and print the server's response
    response_data = client_socket.recv(4096).decode()
    print("Server Response:")
    print(response_data)

    # Close the socket
    client_socket.close()

if __name__ == "__main__":
    filename = "Example.txt"  # Specify the filename of the file to be transferred
    send_file(filename)
