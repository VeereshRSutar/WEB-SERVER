from http.server import BaseHTTPRequestHandler, HTTPServer

# Define valid roll no - date of birth pairs and their corresponding result pages
valid_credentials = {
    '2024GL12': {'02012003': 'index1.html'},
    '2024TK14': {'021292003': 'index2.html'}
}

class MyHTTPHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')
        form_fields = post_data.split('&')
        form_data = {}
        for field in form_fields:
            key, value = field.split('=')
            form_data[key] = value

        if 'rollno' in form_data and 'dob' in form_data:
            rollno = form_data['rollno']
            dob = form_data['dob']
            if rollno in valid_credentials and dob in valid_credentials[rollno]:
                self.send_response(302)
                self.send_header('Location', valid_credentials[rollno][dob])
                self.end_headers()
            else:
                self.send_response(401)
                self.end_headers()
                self.wfile.write(b"Login failed. Please try again.")
        else:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"Bad request. Please provide roll number and date of birth.")

    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            with open('result.html', 'rb') as file:
                self.wfile.write(file.read())
        elif self.path == '/index1.html':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            with open('index1.html', 'rb') as file:
                self.wfile.write(file.read())
        elif self.path == '/index2.html':
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            with open('index2.html', 'rb') as file:
                self.wfile.write(file.read())
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not found.")

def main():
    try:
        server_address = ('', 8080)
        httpd = HTTPServer(server_address, MyHTTPHandler)
        print('Server running on port 8080...')
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('^C received, shutting down the server')
        httpd.socket.close()

if __name__ == '__main__':
    main()
